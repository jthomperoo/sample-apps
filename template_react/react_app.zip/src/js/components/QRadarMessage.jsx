import React from "react";
export default class QRadarMessage extends React.Component {
  render () {
    return <p> QRadar Sample React App</p>;
  }
}