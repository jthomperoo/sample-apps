import React from "react";
import ReactDOM from "react-dom";
import QRadarMessage from "./components/QRadarMessage.jsx"
ReactDOM.render(<QRadarMessage />, document.getElementById("content"));