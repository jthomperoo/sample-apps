#!/bin/bash

npm install --prefix /src